package com.example.newsportal

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
